package com.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.Scanner;

public class Get_Record_ATM {
	private static String driver="com.mysql.cj.jdbc.Driver";
	private static String un="root";
	private static String pass="Punam@123";
	private static String url="jdbc:mysql://localhost:3306/atm";
	
	private static Connection con=null;
	private static Statement st=null;
	private static ResultSet rs=null;
	
	public static void checkBalance() {
		
		
		try {
			//Load the driver 
			Scanner sc=new Scanner(System.in);
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url,un,pass);
			Statement st=con.createStatement();
			System.out.println("Enter username");
			String uname=sc.next();
			String s="select * from acdetails where username='"+uname+"'";
			ResultSet rs=st.executeQuery(s);
			
			if(rs.next()) {
			System.out.println("Enter password");
			String pw=sc.next();
			
			String s3="select * from acdetails where username='"+uname+"' and password='"+pw+"'";
			ResultSet rs1=st.executeQuery(s3);
			if(rs1.next()) {
				String s1="select Available from acdetails where username='"+uname+"'";
				ResultSet rs2=st.executeQuery(s1);
				if(rs2.next()) {
					String bal=rs2.getString(1);
					System.out.println("Your balance is "+bal);
				}
			}else {
				System.out.println("Wrong password");
			}
			
		}else {
			System.out.println("User not exits");
		}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static void withdraw() {
	
			
			try {
				Scanner in=new Scanner(System.in);

				Class.forName(driver);
								
				con=DriverManager.getConnection(url,un,pass);
				  st=con.createStatement();
					System.out.println("Enter username:");
					String ur=in.next();
					String ins="select * from acdetails where username='"+ur+"' ";
					rs=st.executeQuery(ins);
					if(rs.next()) {
					
						System.out.println("Enter Password ");
						String n=in.next();
						
						String ins1="select * from acdetails where username='"+ur+"' and password='"+n+"'";
						rs=st.executeQuery(ins1);
						
						if(rs.next()) {
							int ta=rs.getInt(4);
							
							System.out.println("Enter withdraw amount:");
							int wtd=in.nextInt();
						int to=ta-wtd;
							if(wtd>ta)
							{
								System.out.println("Insufficient Balance!!");
							}
							if(wtd%100!=0 || wtd%500!=0) {
								System.out.println("Enter valid amount:");
							}
							
							//System.out.println(ta);
							if(wtd<ta) {
								
							String s="update acdetails set Available="+to+" where username='"+ur+"'";
							//System.out.println(s);
							int i=st.executeUpdate(s);
							//System.out.println(i);
							if(i>0) {
							 String j="insert into transaction values(0,-"+wtd+","+to+",'"+ur+"')";
							 
							 //System.out.println(j);
							 int ins2=st.executeUpdate(j);
							System.out.println("Collect your cash & card!!");
								System.out.println("Your Account Balance is "+to);
							}
							}
						}else {
							System.out.println("INCORRECT PIN TRY AGAIN LATER");
							
						}
						
					}
					else {
						System.out.println("Enter valid username");
					}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
	}

	public static void deposit() {
		try {
			Scanner in=new Scanner(System.in);

			Class.forName(driver);
							
			con=DriverManager.getConnection(url,un,pass);
			  st=con.createStatement();
				System.out.println("Enter username:");
				String ur=in.next();
				
				String ins2="select * from acdetails where username='"+ur+"' ";
				rs=st.executeQuery(ins2);
				if(rs.next()) {
					
				
				System.out.println("Enter Password ");
				String n=in.next();
				
				String ins="select * from acdetails where username='"+ur+"' and password='"+n+"'";
				rs=st.executeQuery(ins);
				
				if(rs.next()) {
					int ta=rs.getInt(4);
					
					System.out.println("Enter deposit amount:");
					int dep=in.nextInt();
				int to=ta+dep;
					
					//System.out.println(ta);
					if(dep%100==0) {
						
					String s="update acdetails set Available="+to+" where username='"+ur+"'";
					//System.out.println(s);
					int i=st.executeUpdate(s);
					//System.out.println(i);
					if(i>0) {
					 String j="insert into transaction values("+dep+",0,"+to+",'"+ur+"')";
					 
					// System.out.println(j);
					 int ins1=st.executeUpdate(j);
					System.out.println("Amount Deposited!!");
						System.out.println("Your Account Balance is "+to);
					}
					}
				}else {
					System.out.println("INCORRECT PIN TRY AGAIN LATER");
					
				}
				}else {
					System.out.println("Enter valid username");
				}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	public static void viewMiniStatement() {
		Scanner sc=new Scanner(System.in);
					
			try {
				Class.forName(driver);
				con=DriverManager.getConnection(url,un,pass);
				st=con.createStatement();
				System.out.println("Enter username:");
				String ur=sc.next();
				
				String s="select * from acdetails where username='"+ur+"' ";
				rs=st.executeQuery(s);
				if(rs.next()) {
				String s1="select * from transaction where username='"+ur+"'";
				
				
				System.out.println("Deposit\t\tWithdraw\tAvailable\tUsername");
				rs=st.executeQuery(s1);
				while(rs.next())
				{
					System.out.println(rs.getInt(1)+"\t\t"+rs.getInt(2)+"\t\t"+rs.getInt(3)+"\t\t"+rs.getString(4));
				}
			}else {
				System.out.println("Enter valid username");
			}
			}
			
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			  
		
	}
}
