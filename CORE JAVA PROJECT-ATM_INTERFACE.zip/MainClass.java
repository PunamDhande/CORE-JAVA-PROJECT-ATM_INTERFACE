package com.project;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome to GREAT KARIKALAN Machine !!!");
	
		while(true) {
		//System.out.println("Congratulations!! You entered username and password correctly");
		System.out.println("Enter your choice");
		System.out.println("click 1 to check balance");
		System.out.println("click 2 to withdraw");
		System.out.println("click 3 to deposit");
		System.out.println("click 4 to viewMiniStatements");
		
		int ch=sc.nextInt();
		switch(ch) {
		case 1 :
				Get_Record_ATM.checkBalance();
					
				break;
		
		case 2 :
				Get_Record_ATM.withdraw();
				break;
				
				
		case 3 :
				Get_Record_ATM.deposit();
		
				break;
		case 4 :
				Get_Record_ATM.viewMiniStatement();
				break;
	
				
		default: System.out.println("You entered out of range...!! ");
				System.out.println("Please choose correct choice!!");
		}	
		System.out.println("Click n to exit and press any key to continue!! ");
		char ch1=sc.next().charAt(0);
		if(ch1=='n') {
			break;
		}
		}
		
			}

}
